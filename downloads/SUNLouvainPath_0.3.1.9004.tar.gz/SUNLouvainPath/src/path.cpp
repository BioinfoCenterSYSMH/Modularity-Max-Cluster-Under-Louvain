#include <Rcpp.h>
#include "interval_threads.h"
#include "path_common.h"
#include <boost/multiprecision/cpp_int.hpp>
#include <algorithm>
#include <cmath>
#include <map>
#include <numeric>
#include <optional>
#include <limits>
#include <set>
#include <vector>

namespace {
using namespace mml_path_common;
using Neighbours = std::map<int, Integer>;

// Cross-unit edges are stored twice. A unit's volume retains the contribution
// of edges internal to it, including after contraction.
struct Network {
    std::vector<Neighbours> adjacency;
    std::vector<Integer> volume;
    explicit Network(int n) : adjacency(n), volume(n) {}
    void add_edge(int u, int v, const Integer& weight) {
        adjacency[u][v] += weight;
        adjacency[v][u] += weight;
    }
};

// The stored choices precede the first visit whose winner can change at
// the next crossing. Their own first future crossing remains a constraint
// on every subsequent trace that reuses this prefix.
struct Prefix {
    Labels choices;
    Integer next_num = 0, next_den = 0;
    bool end_closed = true;
};

struct Trace {
    const Prefix& inherited;
    const Integer& total;
    Integer num, den;
    bool right, start_closed = true, end_closed = true;
    Integer next_num = 0, next_den = 0;

    Labels choices;
    std::size_t visit = 0, prefix_length = 0;
    std::size_t last_recorded_visit = std::numeric_limits<std::size_t>::max();
    bool closed_before_visit = true, prefix_closed = true;
    Integer prefix_num = 0, prefix_den = 0;
    // Limit move history per vector and worker. Beyond this length the
    // scanner recomputes a visit normally.
    static constexpr std::size_t choice_limit = 4 * 1024 * 1024;

    Trace(const Rational& start, bool right_limit, const Prefix& prefix, const Integer& weight)
        : inherited(prefix), total(weight), right(right_limit) {
        // In rho=r/(2W), all gain comparisons share a smaller integer scale.
        const Rational rho = total == 0 ? Rational(0) :
            Rational(numerator(start), denominator(start) * total);
        num = numerator(rho);
        den = denominator(rho);
        if (right) {
            next_num = prefix.next_num;
            next_den = prefix.next_den;
            end_closed = prefix.end_closed;
        }
    }

    void finish_visit(int target) {
        if (right && choices.size() < choice_limit) choices.push_back(target);
        ++visit;
    }

    Prefix take_prefix() {
        if (prefix_length == 0) return {};
        choices.resize(prefix_length);
        return {std::move(choices), std::move(prefix_num), std::move(prefix_den), prefix_closed};
    }

    // At an exact tie, the smaller penalty wins immediately to the right.
    int compare(const Integer& links, const Integer& volumes, const Integer& scaled_degree,
                int& at_point) const {
        const Integer delta = links * den - volumes * scaled_degree;
        at_point = delta.sign();
        return at_point != 0 || !right ? at_point : -volumes.sign();
    }

    // Keep the earliest crossing, with its deterministic tie decision. The
    // snapshot predates the entire visit, including other tied challengers.
    void constrain(const Integer& a, const Integer& b, bool wins_tie) {
        const int order = next_den == 0 ? -1 : Integer(a * next_den).compare(Integer(next_num * b));
        if (order == 0) end_closed = end_closed && wins_tie;
        if (order < 0) {
            if (last_recorded_visit != visit) {
                last_recorded_visit = visit;
                prefix_length = visit <= choice_limit ? visit : 0;
                prefix_closed = closed_before_visit;
                prefix_num = next_num;
                prefix_den = next_den;
            }
            end_closed = wins_tie;
            next_num = a;
            next_den = b;
        }
    }

    std::optional<Rational> next() const {
        if (next_den == 0) return std::nullopt;
        return Rational(total * next_num, next_den);
    }
};

Labels move_units(const Network& g, Trace& trace) {
    int n = static_cast<int>(g.volume.size());
    Labels group(n);
    std::iota(group.begin(), group.end(), 0);
    std::vector<Integer> volume = g.volume;
    std::vector<Integer> links(n);
    std::vector<Integer> scaled_degree(n);
    for (int u = 0; u < n; ++u) scaled_degree[u] = g.volume[u] * trace.num;
    std::vector<bool> active(n, false);
    Labels targets;
    targets.reserve(n);
    bool changed;
    do {
        poll_path_interrupt();
        changed = false;
        for (int u = 0; u < n; ++u) {
            const int source = group[u];
            trace.closed_before_visit = trace.end_closed;
            if (trace.visit < trace.inherited.choices.size()) {
                int best = trace.inherited.choices[trace.visit];
                if (best != source) {
                    volume[source] -= g.volume[u];
                    volume[best] += g.volume[u];
                    group[u] = best;
                    changed = true;
                }
                trace.finish_visit(best);
                continue;
            }
            targets.clear();
            targets.push_back(source);
            active[source] = true;
            for (const auto& [v, w] : g.adjacency[u]) {
                int target = group[v];
                if (!active[target]) {
                    targets.push_back(target);
                    active[target] = true;
                }
                links[target] += w;
            }
            volume[source] -= g.volume[u];
            int best = source, point_best = source;
            for (int target : targets) {
                if (target == source) continue;
                Integer a = links[target] - links[best];
                Integer b = volume[target] - volume[best];
                int at_point;
                int order = trace.compare(a, b, scaled_degree[u], at_point);
                // The point winner and the right winner among all previously
                // visited candidates have equal values at the exact point.
                if (trace.right && trace.start_closed &&
                    (at_point > 0 || (at_point == 0 && point_best != source && target < point_best))) {
                    point_best = target;
                }
                if (order > 0 || (order == 0 && best != source && target < best)) {
                    best = target;
                }
            }
            if (trace.right) {
                trace.start_closed = trace.start_closed && (point_best == best);
                for (int target : targets) {
                    if (volume[best] > volume[target]) {
                        trace.constrain(links[best] - links[target],
                                        g.volume[u] * (volume[best] - volume[target]),
                                        best == source || (target != source && best < target));
                    }
                }
            }
            for (int target : targets) {
                links[target] = 0;
                active[target] = false;
            }
            volume[best] += g.volume[u];
            group[u] = best;
            if (best != source) changed = true;
            trace.finish_visit(best);
        }
    } while (changed);
    // Canonicalize in vertex order. Contracted units are therefore always
    // visited in increasing order of their smallest original cell index.
    Labels ids(n, -1);
    int count = 0;
    for (int& id : group) {
        if (ids[id] < 0) ids[id] = count++;
        id = ids[id];
    }
    return group;
}

Network contract(const Network& g, const Labels& group, int count) {
    Network coarse(count);
    for (int u = 0; u < static_cast<int>(group.size()); ++u) {
        coarse.volume[group[u]] += g.volume[u];
        for (const auto& [v, w] : g.adjacency[u]) {
            if (u < v && group[u] != group[v]) coarse.add_edge(group[u], group[v], w);
        }
    }
    return coarse;
}

Labels run(const Network& original, Trace& trace) {
    Labels labels(original.volume.size());
    std::iota(labels.begin(), labels.end(), 0);
    const Network* current = &original;
    Network coarse(0);
    for (;;) {
        Labels group = move_units(*current, trace);
        int count = 1 + *std::max_element(group.begin(), group.end());
        for (int& label : labels) label = group[label];
        if (count == static_cast<int>(group.size())) return labels;
        coarse = contract(*current, group, count);
        current = &coarse;
    }
}

// All partitions share the denominator (2W)^2, so their integer numerators
// determine both the maximum and exact ties, even for stored binary weights.
Integer classic_score(const Network& graph, const Labels& labels, const Integer& twice_weight) {
    std::vector<Integer> volume(graph.volume.size());
    Integer internal = 0;
    for (int u = 0; u < static_cast<int>(labels.size()); ++u) {
        volume[labels[u]] += graph.volume[u];
        for (const auto& [v, w] : graph.adjacency[u]) {
            if (u < v && labels[u] == labels[v]) internal += w;
        }
    }
    Integer score = 2 * twice_weight * internal;
    for (const Integer& v : volume) score -= v * v;
    return score;
}

Rcpp::DataFrame recommend(const std::vector<Segment>& segments,
                          const Rcpp::LogicalVector& is_best) {
    Rcpp::CharacterVector status(1, segments.empty() ? "no_eligible_partition" : "undefined_modularity"),
        infimum(1, NA_STRING),
        minimum(1, NA_STRING), witness(1, NA_STRING);
    Rcpp::IntegerVector partition(1, NA_INTEGER), witness_partition(1, NA_INTEGER);
    Rcpp::NumericVector approximate(1, NA_REAL);
    for (const auto& s : segments) {
        if (is_best[s.id - 1] != TRUE) continue;
        Rational low(s.lower);
        Rational sample = low;
        if (s.left_closed) {
            status[0] = "minimum_attained";
            minimum[0] = s.lower;
            approximate[0] = low.convert_to<double>();
            partition[0] = s.id;
        } else {
            status[0] = "open_infimum";
            if (s.upper == "Inf") sample += 1;
            else sample = (low + Rational(s.upper)) / 2;
        }
        infimum[0] = s.lower;
        witness[0] = sample.str();
        witness_partition[0] = s.id;
        break;
    }
    return Rcpp::DataFrame::create(
        Rcpp::_["status"] = status, Rcpp::_["recommended_resolution"] = minimum,
        Rcpp::_["recommended_resolution_numeric"] = approximate,
        Rcpp::_["partition"] = partition, Rcpp::_["infimum"] = infimum,
        Rcpp::_["representative_resolution"] = witness,
        Rcpp::_["representative_partition"] = witness_partition);
}

Network build_graph(int n, Rcpp::IntegerVector i, Rcpp::IntegerVector j, Rcpp::IntegerVector type,
                    Rcpp::NumericVector values, Rcpp::NumericVector overlap, int k, Integer& total) {
    const auto encoding = encode_weights(values, overlap, k);
    Network graph(n);
    for (R_xlen_t idx = 0; idx < i.size(); ++idx) {
        int u = i[idx] - 1, v = j[idx] - 1;
        const Integer& w = encoding.weights[type[idx] - 1];
        graph.add_edge(u, v, w);
        graph.volume[u] += w;
        graph.volume[v] += w;
        total += 2 * w;
    }
    return graph;
}

IntervalData scan_interval(const Network& graph, const Integer& total, Rational start,
                           const std::optional<Rational>& limit, bool include_upper) {
    PartitionIndex ids;
    auto id_for = [&](Labels labels) {
        return ids.try_emplace(std::move(labels), static_cast<int>(ids.size()) + 1).first->second;
    };
    IntervalData block;
    Prefix previous;
    int previous_id = 0;
    bool previous_closed = false;
    for (;;) {
        poll_path_interrupt();
        const std::string here = start.str();
        auto exact_point_id = [&]() {
            Trace point(start, false, previous, total);
            return id_for(run(graph, point));
        };
        if (limit && start == *limit) {
            const int point_id = previous_closed ? previous_id : exact_point_id();
            append(block.segments, point_id, here, here, true, true);
            break;
        }

        Trace after(start, true, previous, total);
        Labels after_labels = run(graph, after);
        // Assign IDs in point-then-interval order, including when only the
        // exact point yields a third, distinct partition.
        int point_id;
        int id;
        if (previous_closed || !after.start_closed) {
            point_id = previous_closed ? previous_id : exact_point_id();
            id = id_for(std::move(after_labels));
        } else {
            id = id_for(std::move(after_labels));
            point_id = id;
        }
        append(block.segments, point_id, here, here, true, true);
        auto next = after.next();
        previous = after.take_prefix();
        previous_id = id;
        previous_closed = after.end_closed;
        // A right trace certifies the open interval up to the next crossing or the cut.
        if (limit && (!next || *next >= *limit)) {
            append(block.segments, id, here, limit->str(), false, false);
            if (!include_upper) break;
            if (!next || *next > *limit) previous_closed = true;
            start = *limit;
            continue;
        }
        append(block.segments, id, here, next ? next->str() : "Inf", false, false);
        if (!next) break;
        start = *next;
    }
    block.partitions = take_partitions(ids);
    block.numerators.reserve(block.partitions.size());
    for (const auto& labels : block.partitions) {
        poll_path_interrupt();
        block.numerators.push_back(classic_score(graph, labels, total));
    }
    return block;
}

#include "structural.h"
#include "cluster_cap.h"

IntervalData scan_parallel(const StructuralPlan& plan, const std::vector<Rational>& starts,
                           const std::optional<Rational>& limit, bool include_upper,
                           int workers, int max_clusters) {
    auto blocks = map_intervals(starts.size(), workers, [&](std::size_t idx) {
        const bool last = idx + 1 == starts.size();
        auto end = last ? limit : std::optional<Rational>(starts[idx + 1]);
        return eligible_partitions(plan.scan(starts[idx], end, last && include_upper), max_clusters);
    });
    return merge_intervals(std::move(blocks));
}

Rcpp::List to_r(const IntervalData& path, const Integer& total, int n) {
    const std::size_t count = path.partitions.size();
    Rcpp::IntegerMatrix membership(n, count);
    for (std::size_t idx = 0; idx < count; ++idx) {
        Rcpp::checkUserInterrupt();
        const auto& labels = path.partitions[idx];
        for (std::size_t u = 0; u < labels.size(); ++u) membership(u, idx) = labels[u] + 1;
    }
    Rcpp::CharacterVector exact(count, NA_STRING);
    Rcpp::NumericVector modularity(count, NA_REAL);
    Rcpp::LogicalVector is_best(count, NA_LOGICAL);
    if (total > 0 && count != 0) {
        Integer den = total * total;
        Integer maximum = *std::max_element(path.numerators.begin(), path.numerators.end());
        for (std::size_t idx = 0; idx < count; ++idx) {
            Rational q(path.numerators[idx], den);
            exact[idx] = q.str();
            modularity[idx] = q.convert_to<double>();
            is_best[idx] = path.numerators[idx] == maximum;
        }
    }
    return Rcpp::List::create(
        Rcpp::_["membership"] = membership,
        Rcpp::_["scores"] = Rcpp::DataFrame::create(
            Rcpp::_["modularity"] = modularity, Rcpp::_["modularity_exact"] = exact,
            Rcpp::_["is_max"] = is_best),
        Rcpp::_["recommendation"] = recommend(path.segments, is_best),
        Rcpp::_["intervals"] = interval_frame(path.segments));
}
#include "seurat_output.h"
} // namespace

// [[Rcpp::export(rng = false)]]
Rcpp::List resolution_ranges_cpp(Rcpp::CharacterVector split_points, std::string r_max) {
    auto limit = upper_limit(r_max);
    auto splits = interior_splits(split_points, limit);
    Rcpp::CharacterVector points(splits.size());
    for (std::size_t i = 0; i < splits.size(); ++i) points[i] = splits[i].str();
    return Rcpp::List::create(Rcpp::_["split_points"] = points,
                              Rcpp::_["r_max"] = limit ? limit->str() : std::string("Inf"));
}

// [[Rcpp::export(rng = false)]]
Rcpp::List enumerate_interval_cpp(int n, Rcpp::IntegerVector i, Rcpp::IntegerVector j,
                                  Rcpp::IntegerVector type, Rcpp::NumericVector values,
                                  Rcpp::NumericVector overlap, int k, std::string lower,
                                  std::string upper, bool include_upper) {
    auto limit = upper_limit(upper);
    auto start = resolution(lower);
    if (limit && (*limit < start || (*limit == start && !include_upper))) {
        Rcpp::stop("The resolution interval must be nonempty.");
    }
    Integer total = 0;
    auto graph = build_graph(n, i, j, type, values, overlap, k, total);
    const StructuralPlan plan(graph, total);
    Rcpp::List result = to_r(plan.scan(start, limit, include_upper), total, n);
    result["search_plan"] = plan.metadata();
    return result;
}

// [[Rcpp::export(rng = false)]]
Rcpp::List enumerate_parallel_cpp(int n, Rcpp::IntegerVector i, Rcpp::IntegerVector j,
                                  Rcpp::IntegerVector type, Rcpp::NumericVector values,
                                  Rcpp::NumericVector overlap, int k, Rcpp::CharacterVector split_points,
                                  std::string r_max, int workers) {
    auto limit = upper_limit(r_max);
    auto starts = interior_splits(split_points, limit);
    starts.insert(starts.begin(), Rational(0));
    if (workers < 1) Rcpp::stop("workers must be a positive integer.");
    Integer total = 0;
    auto graph = build_graph(n, i, j, type, values, overlap, k, total);
    const StructuralPlan plan(graph, total);
    Rcpp::List result = to_r(scan_parallel(plan, starts, limit, limit.has_value(), workers, 0), total, n);
    result["search_plan"] = plan.metadata();
    return result;
}

// [[Rcpp::export(rng = false)]]
Rcpp::List enumerate_capped_parallel_cpp(int n, Rcpp::IntegerVector i, Rcpp::IntegerVector j,
                                         Rcpp::IntegerVector type, Rcpp::NumericVector values,
                                         Rcpp::NumericVector overlap, int k,
                                         Rcpp::CharacterVector split_points, std::string r_max,
                                         int workers, int max_clusters) {
    if (workers < 1) Rcpp::stop("workers must be a positive integer.");
    if (max_clusters < 0) Rcpp::stop("max_clusters must be nonnegative.");
    const auto requested = upper_limit(r_max);
    const int cap = max_clusters >= n ? 0 : max_clusters;
    Integer total = 0;
    auto graph = build_graph(n, i, j, type, values, overlap, k, total);
    auto bound = edge_cluster_bound(graph, total, cap);
    const StructuralPlan plan(graph, total);
    auto meta = plan.metadata();
    bool impossible = cap && Rcpp::as<int>(meta["n_components"]) > cap;
    if (impossible) {
        // Cells from different connected components never share a group.
        bound = Rational(0);
    } else if (cap) {
        const Rational singleton_tail(Rcpp::as<std::string>(meta["singleton_tail_start"]));
        if (!bound || singleton_tail < *bound) bound = singleton_tail;
    }
    const bool cut = bound && (!requested || *bound <= *requested);
    const auto limit = cut ? bound : requested;
    const bool include_upper = !cut && requested.has_value();
    auto starts = interior_splits(split_points, limit);
    Rcpp::CharacterVector actual_splits(starts.size());
    for (std::size_t idx = 0; idx < starts.size(); ++idx) actual_splits[idx] = starts[idx].str();
    starts.insert(starts.begin(), Rational(0));
    int used = impossible ? 0 : std::min(static_cast<std::size_t>(workers), starts.size());
    IntervalData path;
    if (!impossible) path = scan_parallel(plan, starts, limit, include_upper, used, cap);
    Rcpp::List result = to_r(path, total, n);
    meta["cluster_bound"] = bound ? bound->str() : std::string("Inf");
    Rcpp::CharacterVector scanned(1, NA_STRING);
    if (!impossible) scanned[0] = limit ? limit->str() : std::string("Inf");
    meta["scan_r_max"] = scanned;
    meta["scan_upper_closed"] = include_upper;
    meta["scan_split_points"] = actual_splits;
    meta["effective_workers"] = used;
    result["search_plan"] = meta;
    return result;
}

// [[Rcpp::export(rng = false)]]
Rcpp::List enumerate_path_cpp(int n, Rcpp::IntegerVector i, Rcpp::IntegerVector j,
                              Rcpp::IntegerVector type, Rcpp::NumericVector values,
                              Rcpp::NumericVector overlap, int k) {
    return enumerate_interval_cpp(n, i, j, type, values, overlap, k, "0", "Inf", false);
}

// [[Rcpp::export(rng = false)]]
Rcpp::List seurat_results_cpp(int n, Rcpp::IntegerVector i, Rcpp::IntegerVector j,
                              Rcpp::IntegerVector type, Rcpp::NumericVector values,
                              Rcpp::NumericVector overlap, int k, Rcpp::IntegerMatrix raw,
                              Rcpp::DataFrame intervals, bool group_singletons, int cap,
                              Rcpp::CharacterVector points, std::string r_max, int fxn,
                              Rcpp::Function sample_tie) {
    Integer total = 0;
    auto graph = build_graph(n, i, j, type, values, overlap, k, total);
    SeuratQueries queries(points, intervals, n, upper_limit(r_max), fxn);
    std::map<int, int> tie_cache;
    PartitionIndex unique;
    IntervalData result;
    std::vector<int> final_ids(raw.ncol(), 0);
    for (int col = 0; col < raw.ncol(); ++col) {
        Rcpp::checkUserInterrupt();
        Labels labels(n);
        for (int u = 0; u < n; ++u) labels[u] = raw(u, col) - 1;
        auto native = grouped_seurat_labels(std::move(labels), graph, group_singletons,
                                            sample_tie, tie_cache);
        Labels canonical(n), map(n + 1, -1);
        int groups = 0;
        for (int u = 0; u < n; ++u) {
            int& label = map[native[u]];
            if (label < 0) label = groups++;
            canonical[u] = label;
        }
        if (!cap || groups <= cap) {
            auto item = unique.try_emplace(std::move(canonical), static_cast<int>(unique.size()) + 1);
            final_ids[col] = item.first->second;
            if (item.second) result.numerators.push_back(classic_score(graph, item.first->first, total));
        }
        auto found = queries.columns.find(col + 1);
        if (found != queries.columns.end()) {
            for (int q : found->second) {
                if (final_ids[col] == 0) { queries.status[q] = "filtered_max_clusters"; continue; }
                queries.final[q] = final_ids[col];
                queries.status[q] = "ok";
                for (int u = 0; u < n; ++u) queries.idents(u, q) = native[u];
            }
        }
    }
    result.partitions = take_partitions(unique);
    Rcpp::IntegerVector ids = intervals["partition"];
    Rcpp::CharacterVector lo = intervals["lower"], hi = intervals["upper"];
    Rcpp::LogicalVector lc = intervals["lower_closed"], hc = intervals["upper_closed"];
    for (R_xlen_t s = 0; s < ids.size(); ++s) {
        int id = final_ids[ids[s] - 1];
        if (id) append(result.segments, id, Rcpp::as<std::string>(lo[s]), Rcpp::as<std::string>(hi[s]), lc[s], hc[s]);
    }
    auto answer = to_r(result, total, n);
    answer["queries"] = Rcpp::DataFrame::create(
        Rcpp::_["resolution"] = queries.text, Rcpp::_["status"] = queries.status,
        Rcpp::_["raw_partition"] = queries.raw, Rcpp::_["partition"] = queries.final);
    answer["query_idents"] = queries.idents;
    return answer;
}
